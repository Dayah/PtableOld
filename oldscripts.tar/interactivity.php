﻿<? // pack("CCC", 0xEF,0xBB,0xBF); ?>
if (document.addEventListener)
	document.addEventListener("DOMContentLoaded", load_complete, false);
else if (/*@cc_on @_jscript || @*/ false)
	load_complete();
else
	window.onload = load_complete;

/* function benchmark() {
	view_start = (new Date()).getTime();
	for (var y = 0; y <= 118; y++) on_mouse_over(y);
	alert((new Date()).getTime() - view_start);
} */

function load_complete() {
	if (document.cookie.indexOf("demo") !== -1) document.getElementById("Ad").style.display = "none";

	n_atomic = 0; n_name = (language == "zh") ? 2 : 4; n_symbol = 2; n_mass = 5;
	i_neutrons = 0, i_isomass = 1, i_binding = 2, i_masscontrib = 3, i_halflife = 4, i_decaymode = 5, i_width = 6;
	schemebase = (scheme === "night" ? "000000" : "FFFFFF");
	schemehigh = (scheme === "night" ? "FFFFFF" : "000000");
	highlight = calc_color(1, schemebase, "FFFF00", 0, 2);

	flash_ids = [], flash_num = 0, flash_value = 0;
	lastIsotope = false;
	lastSeries = false;
	lastDetach = false;
	lastOrbital = false;
	hovered_state = false;
	oldYellow = false;
	active = false;
	waiting = false;
	keyscroll = false;
	resizewidth = document.documentElement.clientWidth;
	resizeheight = document.documentElement.clientHeight;
	firstDetails = true;
	dataset = "series";
	tab = "SeriesTab";
	winlist = [];
	animation_steps = 10, aniX = 0;
	iMove = -1;
	key_next = false;

	cache_objects();
	wholetable.inverted = false;
	allclasses = wholetable.className;
	aufbau = [];
	var temp = document.getElementById("Hund").tBodies[0].rows[0].cells;
	for (var x = 0; x < temp.length; x++) aufbau.push(temp[x].getElementsByTagName("table")[0].getElementsByTagName("th"));
	
	temperature = 273;
	attach_class_hovers();
//	if (!("writingMode" in document.body.style)) quit lying about supporting writingMode Safari, Opera
	if (/*@cc_on ! @*/true) no_sideways();
	init_layout();
	series = [[]];
	for (var i = 1; i <= 118; i++) {
		element_ids[i].idx = i;
		series[0][i] = element_ids[i].childNodes[n_mass].innerHTML;
	}
	chemical = series;
	current_colors = [], default_colors = [], search_colors = [];
	save_colors(default_colors);

	isotope = [[0,3,2,2,3,2,3,3,3,2,3,2,3,2,4,3,5,3,7,3,9,5,6,4,5,4,7,5,8,2,7,2,7,3,9,2,9,5,9,5,8,5,9,5,10,5,9,6,11,2,11,3,11,3,13,4,8,3,8,3,7,3,8,4,7,3,8,5,11,5,11,4,8,7,7,2,11,7,9,5,11,3,6,3,3,1,2,3,4,3,6,6,6,3,6,3,8,5,7,4,4,3,3,1,1,1,1,2,2,1,1,1,1,1,1,1,1,1,1],[1,7,9,10,12,14,15,16,17,18,19,20,22,22,23,23,24,24,24,24,24,25,26,26,26,26,28,29,31,29,30,31,32,33,30,31,32,32,33,33,33,33,33,34,34,34,34,38,38,39,39,37,38,37,38,40,40,39,39,39,38,38,38,38,36,36,36,36,35,35,35,35,36,36,35,35,35,36,37,37,40,37,38,36,33,31,34,34,33,31,30,29,26,20,20,19,20,20,20,19,19,18,17,16,16,16,16,16,15,15,15,12,9,5,5,5,4,2,1]];
	orbital = [[0,1,0,1,2,3,4,3,2,1,0,1,2,3,4,5,6,5,0,1,2,3,4,5,6,4,3,4,4,2,2,3,4,5,6,7,4,1,2,3,4,5,6,7,6,6,4,4,2,3,4,5,6,7,6,3,2,3,4,4,3,3,3,3,3,4,3,3,3,3,3,3,4,5,6,7,7,6,6,7,2,3,4,5,6,7,6,3,2,3,4,5,6,6,6,4,4,4,4,4,3,3,3,3,4,5,6,7,,,,,,,,,,,6]];
<?
$link = mysqli_connect("localhost", "ptable", "lucent", "ptable") or die(mysqli_connect_error()); 
$result = mysqli_query($link, "SELECT electronstring,melt,boil FROM property") or die(mysqli_error($link));
while ($row = mysqli_fetch_assoc($result))
	foreach($row as $key=>$data)
		if ($key == "electronstring")	$final[$key][] = '"' . $data . '"';
		else if ($data)					$final[$key][] = $data;

mysqli_free_result($result);
foreach ($final as $key=>$set)
	echo "\t", $key, " = [", ($key == "melt" || $key == "boil" ? "[" . (max($set) + 25) : ""), ",", implode(",", $set), ($key == "melt" || $key == "boil" ? "]" : ""), "];\n";
?>

	shellL = {"s": 0, "p": 1, "d": 2, "f": 3};

	datasets = {"PropertyTab": ["melt", "boil", "electroneg", "discover", "affinity", "heat", "radius", "abundance", "ionize", "density", "hardness", "conductivity"],
		"IsotopeTab": ["isomass", "binding", "masscontrib", "halflife", "width", "neutrons"]};
	spec_state = {"unit": [" K"], "slidermin": 0, "slidermax": 6000, "Legend": ["State"]};
	spec_series = {"unit": [" K"], "slidermin": 0, "slidermax": 6000, "Legend": ["<span>Atomic </span>Mass"], "replace": [,], "subset": 0};
	spec_chemical = spec_series;
	spec_orbital = spec_series;
	spec_isotope = {"unit": [" K"], "Legend": ["Isotopes","Isotopes"], "values": ["Selected", "All"], "subset": 0};

	spec_melt = {"unit": [" K"], "startcolor": "6666FF", "endcolor": "FF0000", "defaultcolor": schemebase, "slidermin": 0, "slidermax": 6000, "Legend": ["Kelvin"], "replace": [,], "subset": 0};
	spec_boil = {"unit": [" K"], "startcolor": "6666FF", "endcolor": "FF0000", "defaultcolor": schemebase, "slidermin": 0, "slidermax": 6000, "Legend": ["Kelvin"], "replace": [,], "subset": 0};
	spec_electroneg = {"unit": [""], "startcolor": "FFFF66", "endcolor": "FF0000", "defaultcolor": schemebase, "Legend": ["Pauling"], "scale": ["lin"], "replace": [,], "subset": 0};
	spec_radius = {"unit": [" pm"," pm"," pm"], "startcolor": schemebase, "endcolor": "008800", "defaultcolor": schemebase, "Legend": ["pm","pm","pm"], "values": ["Calculated","Empirical","Covalent"], "scale": ["lin","lin","lin"], "replace": [,], "subset": 0};
	spec_hardness = {"unit": [" MPa",""," MPa"], "startcolor": schemebase, "endcolor": "008800", "defaultcolor": schemebase, "Legend": ["MPa","","MPa"], "values": ["Brinell","Mohs","Vickers"], "scale": ["log","lin","log"], "replace": [,], "subset": 0};
	spec_ionize = {"unit": [" kJ/mol"," kJ/mol"," kJ/mol"," kJ/mol"," kJ/mol"," kJ/mol"," kJ/mol"," kJ/mol"," kJ/mol"," kJ/mol"," kJ/mol"," kJ/mol"," kJ/mol"," kJ/mol"," kJ/mol"," kJ/mol"," kJ/mol"," kJ/mol"," kJ/mol"," kJ/mol"," kJ/mol"," kJ/mol"," kJ/mol"," kJ/mol"," kJ/mol"," kJ/mol"," kJ/mol"," kJ/mol"," kJ/mol"," kJ/mol"], "startcolor": "66FF66", "endcolor": "6666FF", "defaultcolor": schemebase, "Legend": ["kJ/mol","kJ/mol","kJ/mol","kJ/mol","kJ/mol","kJ/mol","kJ/mol","kJ/mol","kJ/mol","kJ/mol","kJ/mol","kJ/mol","kJ/mol","kJ/mol","kJ/mol","kJ/mol","kJ/mol","kJ/mol","kJ/mol","kJ/mol","kJ/mol","kJ/mol","kJ/mol","kJ/mol","kJ/mol","kJ/mol","kJ/mol","kJ/mol","kJ/mol","kJ/mol"], "values": ["1st","2nd","3rd","4th","5th","6th","7th","8th","9th","10th","11th","12th","13th","14th","15th","16th","17th","18th","19th","20th","21st","22nd","23rd","24th","25th","26th","27th","28th","29th","30th"], "scale": ["log","log","log","log","log","log","log","log","log","log","log","log","log","log","log","log","log","log","log","log","log","log","log","log","log","log","log","log","log","log"], "replace": [,], "subset": 0};
	spec_discover = {"unit" : [""], "slidermin": 1730, "slidermax": 2008, "default": 2008, "startcolor" : "FFFFFF", "endcolor" : "666600", "defaultcolor": "FFFFFF", "Legend": ["Year"], "replace": [,], "subset": 0};
	spec_density = {"unit": [" kg/m³"," kg/m³"], "startcolor": schemebase, "endcolor": "006666", "defaultcolor": schemebase, "Legend": ["kg/m³","kg/m³"], "values": ["STP","Liquid"], "scale": ["lin","lin"], "replace": [,], "subset": 0};
	spec_affinity = {"unit": [" kJ/mol"], "startcolor": "006600", "endcolor": schemebase, "defaultcolor": "CCCCCC", "Legend": ["kJ/mol"], "scale": ["log"], "replace": [,], "subset": 0};
	spec_abundance = {"unit": ["%","%","%","%","%","%"], "startcolor": schemebase, "endcolor": "3333FF", "defaultcolor": "CCCCCC", "Legend": ["%","%","%","%","%","%"], "values": ["Universe","Solar","Meteor","Crust","Ocean","Human"], "scale": ["log","log","log","log","log","log"], "replace": [/e(.*)/, "×10<sup>$1<\/sup>"], "subset": 0};
	spec_heat = {"unit": [" J/kgK"," kJ/mol"," kJ/mol"], "startcolor": schemebase, "endcolor": "FF0000", "defaultcolor": "CCCCCC", "Legend": [" J/kgK"," kJ/mol"," kJ/mol"], "values": ["Specific","Vaporization","Fusion"], "scale": ["log","lin","log"], "replace": [,], "subset": 0};
	spec_conductivity = {"unit": [" W/mK"," MS/m"], "startcolor": schemebase, "endcolor": "FF0000", "defaultcolor": "BBBBBB", "Legend": ["W/mK","MS/m"], "values": ["Thermal","Electric"], "scale": ["lin","lin"], "replace": [/e(.*)/, "×10<sup>$1<\/sup>"], "subset": 0};
	spec_electronstring = {"unit": [""], "replace": [/(\d+)(\d[spdf]|$)/g, "<sup>$1<\/sup> $2"], "subset": 0};

	spec_masscontrib = {"unit": ["%"], "startcolor": "FFFFFF", "endcolor": "FF0000", "defaultcolor": "CCCCCC", "Legend": ["%"], "scale": "lin", "replace": [,], "subset": 0};
	spec_isomass = {"unit": [""], "startcolor": "FFFFFF", "endcolor": "FF0000", "defaultcolor": "CCCCCC", "Legend": [""], "scale": "lin", "replace": [,], "subset": 0};
	spec_halflife = {"unit": ["Time"], "startcolor": "FFFFFF", "endcolor": "000000", "defaultcolor": "000000", "scale": "log", "subset": 0};
	spec_binding = {"unit": [""], "startcolor": "FFFFFF", "endcolor": "00FF00", "defaultcolor": "CCCCCC", "scale": "lin", "subset": 0};
	spec_isomass = {"unit": [""], "startcolor": "FFFFFF", "endcolor": "0000FF", "defaultcolor": "CCCCCC", "scale": "lin", "subset": 0};
	spec_width = {"unit": [""], "startcolor": "FFFFFF", "endcolor": "00FFFF", "defaultcolor": "CCCCCC", "scale": "lin", "subset": 0};

	document.getElementById("masses").onclick = click_checkbox;
	document.getElementById("names").onclick = click_checkbox;
	document.getElementById("electrons").onclick = click_checkbox;
	widecheck.onclick = click_checkbox;
	tab_to_anchor("PropertyTab"); tab_to_anchor("IsotopeTab"); tab_to_anchor("OrbitalTab");
	searchinput.onkeyup = function () { search(this.value); };
	searchinput.onkeydown = function (e) { e = e || event; e.cancelBubble = true; };
	document.forms["visualize"].onkeydown = function (e) { e = e || event; e.cancelBubble = true; };
	document.getElementById("langswitch").onkeydown = function (e) { e = e || event; e.cancelBubble = true; };
	if (typeof wholetable.onmouseleave != "undefined")
		wholetable.onmouseleave = hide_closeup;
	else 
		wholetable.onmouseout = function (e) {
			for (var el = e.relatedTarget; el && el != wholetable; el = el.parentNode);
			if (!el) hide_closeup();
		};

	searchinput.onfocus = function () {
		on_mouse_out();
		save_colors(search_colors);
		search_active = true;
		if (this.value == "# or Name") this.value = "";
		search(this.value);
	};
	searchinput.onblur = function () {
		this.value = "# or Name";
		search_active = false;
		if (tab !== "PropertyTab" || dataset === "chemical") restore_colors(current_colors = []);
		else restore_colors(current_colors = search_colors.concat());
		on_mouse_over(active);
	};
	document.getElementById("SliderTrack").onmousedown = slider_skip;
	document.getElementById("SliderTrack").onmouseup = slider_release;
	display.onkeyup = slider_release;
	display.onkeydown = slider_arrow;
	display.onkeypress = slider_keypress;
	display.onfocus = hover_state;
	display.onblur = unhover_state;
	var tds = document.getElementsByTagName("td");
	for (var x = 0; x < tds.length; x++) if (tds[x].className.indexOf("InnerBorder") !== -1) {
		tds[x].onmouseover = function () {
			document.getElementById("NonFooter").className = "InnerHover";
			widecheck.parentNode.style.backgroundColor = "yellow";
			widecheck.nextSibling.style.color = "black";
		};
		tds[x].onmouseout = function () {
			document.getElementById("NonFooter").className = "";
			widecheck.parentNode.style.backgroundColor = "";
			widecheck.nextSibling.style.color = "";
		};
		tds[x].onclick = function () { widecheck.checked = true; widecheck.onclick(); }
	}
	if (document.addEventListener) {
		document.getElementById("SliderTrack").addEventListener("DOMMouseScroll", wheelscroll, false);
		display.addEventListener("DOMMouseScroll", wheelscroll, false);
	} else display.onmousewheel = document.getElementById("SliderTrack").onmousewheel = wheelscroll;
	// onfocus and onblur events for above to activate deactive mousewheel
	document.onkeydown = keyboard_nav;
	slider.onmousedown = startSlide;

	window.onresize = function () {
		if (resizewidth != document.documentElement.clientWidth) {
			clearTimeout(arguments.callee.timer);
			arguments.callee.timer = setTimeout(resize_hunt, 200);
		}
		resizewidth = document.documentElement.clientWidth;
		resizeheight = document.documentElement.clientHeight;
	};

	if (document.getElementById("masses").checked) document.getElementById("masses").onclick();
	if (document.getElementById("names").checked) document.getElementById("names").onclick();
	if (document.getElementById("electrons").checked) document.getElementById("electrons").onclick();
	if (widecheck.checked) widecheck.onclick();

	init_slider();
	resize_hunt();
	setTimeout(sweep, 300);
//	social_hunt();
}

function social_hunt() {
	var sl = SocialHistory();
	document.getElementById("delicious").style.display = sl.doesVisit("Del.icio.us") === true ? "" : "none";
	document.getElementById("facebook").style.display = sl.doesVisit("Facebook") === true ? "" : "none";
}

function cache_objects() {
	tempK = document.getElementById("Temperature").rows[0].cells[0];
	tempC = document.getElementById("Temperature").rows[1].cells[0];
	tempF = document.getElementById("Temperature").rows[2].cells[0];
	tempState = document.getElementById("l_state").getElementsByTagName("span")[0];
	widecheck = document.getElementById("wide");
	wholetable = document.getElementById("Main");
	detail = document.getElementById("CloseupElement");
	detailelectrons = document.getElementById("CloseupElectron");
	key_id = document.getElementById("KeyContainer");
	display = document.getElementById("SliderDisplay");
	slider = document.getElementById("SliderBar");
	searchinput = document.getElementById("SearchInput");
	wikibox = document.getElementById("WikiBox");
	property_ids = [], orbital_ids = [], block_ids = [];
	var temp_property = document.getElementById("Properties").getElementsByTagName("td");
	for (var x = 0; x < temp_property.length; x++)
		if (temp_property[x].id === temp_property[x].id.toUpperCase() && temp_property[x].id.length)
			property_ids[temp_property[x].id.toLowerCase()] = temp_property[x];
	property_ids["electronstring"] = document.getElementById("ELECTRONSTRING");
	orbital_ids["lmn"] = document.getElementById("lmn");
	orbital_ids["Hund"] = document.getElementById("Hund");
	orbital_ids["OrbitalString"] = document.getElementById("OrbitalString");
	block_ids["Orbital"] = document.getElementById("Orbital");
}

function resize_hunt() {
	var sheet_ids = ["masses", "names", "electrons"], index = -1, before = [], after = [];
	for (x in sheet_ids) before[x] = document.getElementById(sheet_ids[x]).checked;
	while (document.documentElement.offsetWidth >= document.documentElement.scrollWidth && index < sheet_ids.length - 1) {
		if (!document.getElementById(sheet_ids[++index]).checked) {
			document.getElementById(sheet_ids[index]).checked = true;
			document.getElementById(sheet_ids[index]).onclick();
		}
	}
	index = sheet_ids.length;
	while (document.documentElement.offsetWidth < document.documentElement.scrollWidth && index > 0) {
		if (document.getElementById(sheet_ids[--index]).checked) {
			document.getElementById(sheet_ids[index]).checked = false;
			document.getElementById(sheet_ids[index]).onclick();
		}
	}
	for (x in sheet_ids)
		if (before[x] !== document.getElementById(sheet_ids[x]).checked)
			after.push(document.getElementById(sheet_ids[x]).parentNode);
	init_flash(after);
}

function attach_class_hovers() {
	var row = document.getElementById("Series").tBodies[0].rows;

	var collect_class = row[2].cells[0].className + " ";
	for (var x = 0; x < 5; x++) collect_class += row[1].cells[x].className + " ";
	row[0].cells[0].classes = collect_class;

	collect_class = "";
	for (var x = 5; x < 7; x++) collect_class += row[1].cells[x].className + " ";
	row[0].cells[1].classes = collect_class;

	row[0].cells[0].firstChild.onmouseover = row[0].cells[1].firstChild.onmouseover = row[0].cells[0].firstChild.onfocus = row[0].cells[1].firstChild.onfocus = multi_series;
	row[0].cells[0].firstChild.onblur = row[0].cells[1].firstChild.onblur = series_leave;

	for (var x = 1; x <= 2; x++)
		for (var y = 0; y < row[x].cells.length; y++)
			if (row[x].cells[y].className) {
				row[x].cells[y].firstChild.onmouseover = row[x].cells[y].firstChild.onfocus = series_hover;
				row[x].cells[y].firstChild.onblur = series_leave;
			}

	if (typeof document.getElementById("Series").onmouseleave !== "undefined")
		document.getElementById("Series").onmouseleave = document.getElementById("Block").onmouseleave = series_leave;
	else 
		document.getElementById("Series").onmouseout = document.getElementById("Block").onmouseout = function (e) {
			for (var el = e.relatedTarget; el && (el != document.getElementById("Series") && el != document.getElementById("Block")); el = el.parentNode);
			if (!el) series_leave();
		};

	var links = document.getElementById("Series").getElementsByTagName("a");
	for (var x = 0; x < links.length; x++)
		links[x].onclick = click_wiki;

	row = document.getElementById("Block").tBodies[0].rows;
	for (var x = 0; x < row.length; x++)
		row[x].cells[0].onmouseover = function () { clear_series(); wholetable.className = this.className; };

	row = document.getElementById("MatterState").tBodies[0].rows;
	for (var x = 0; x < row.length; x++)
		row[x].cells[0].onmouseover = hover_state;
	if (typeof document.getElementById("MatterState").onmouseleave !== "undefined")
		document.getElementById("MatterState").onmouseleave = unhover_state;
	else 
		document.getElementById("MatterState").onmouseout = function (e) {
			for (var el = e.relatedTarget; el && (el != document.getElementById("MatterState")); el = el.parentNode);
			if (!el) unhover_state();
		};
}

function hover_state() {
	el = this || srcElement;
	display.style.backgroundColor = "yellow";
	if (hovered_state !== el.className && window["spec_" + dataset]["unit"][0] == " K") {
		if (hovered_state) unhover_state(el);
		hovered_state = el.className;
		series_to_temp();
		if (hovered_state && (tab !== "PropertyTab" || dataset === "chemical")) {
			el.parentNode.className = "InvertState";
			for (var i = 1; i <= 118; i++) {
				if (element_ids[i].state === hovered_state) {
					set_bgcolor(i, element_ids[i].childNodes[n_symbol].style.color);
					element_ids[i].childNodes[n_symbol].style.color = element_ids[i].style.color = electron_ids[i].style.color = "white";
				}
			}
		}
	}
}

function unhover_state() {
	display.style.backgroundColor = "";
	row = document.getElementById("MatterState").tBodies[0].rows;
	for (var x = 0; x < row.length; x++) row[x].className = "";
	if (dataset !== "state" && dataset !== "melt" && dataset !== "boil") temp_to_series();
	if (hovered_state && (tab !== "PropertyTab" || dataset === "chemical")) {
		for (var i = 1; i <= 118; i++) {
			if (element_ids[i].state === hovered_state) {
				element_ids[i].childNodes[n_symbol].style.color = element_ids[i].style.backgroundColor;
				element_ids[i].style.color = electron_ids[i].style.color = "";
			}
		}
		restore_colors(current_colors = []);
	}
	hovered_state = false;
}

function clear_series() {
	if (lastSeries) {
		lastSeries.style.backgroundColor = "";
		lastSeries.style.color = "";
	}
	if (active) {
		var series = get_series(active), orbital = get_orbital(active);
		if (series && series !== " " && series !== "Undiscovered") document.getElementById(series).className = series;
		if (orbital && orbital !== " ") document.getElementById(orbital).className = orbital;
	}
	lastSeries = false;
}

function multi_series() {
	if (tab !== "PropertyTab" || dataset === "chemical") {
		clear_series();
		this.parentNode.style.backgroundColor = "#999";
		this.parentNode.style.color = "white";
		wholetable.className = this.parentNode.classes;
		lastSeries = this.parentNode;
	}
}

function series_hover(e) {
	if (tab !== "PropertyTab" || dataset === "chemical") {
		clear_series();
		wholetable.className = (this || srcElement).parentNode.className;
	}
}

function series_leave() {
	if (tab !== "PropertyTab" || dataset === "chemical") {
		clear_series();
		wholetable.className = allclasses + (tab === "OrbitalTab" ? " s p d f" : "");
		if (active) {
			var series = get_series(active), orbital = get_orbital(active);
			if (series && series !== " " && series !== "Undiscovered") document.getElementById(series).className = "";
			if (orbital && orbital !== " ") document.getElementById(orbital).className = "";
		}
	}
}

function dataset_changed(update, el) {
	el = (el || this || srcElement).getElementsByTagName("input");
	for (var i = 0; i < el.length; i++)
		if (el[i].checked && el[i].value != dataset) {
			if (update === true)	return el[i].value;
			else					switch_viz(el[i].value);
		}
}

function subset_changed(update) {
	el = document.forms["AltSlider"];
	for (var i = 0; i < el.length; i++)
		if (el[i].checked && el[i].value != window["spec_" + dataset]["subset"]) {
			if (update === true)	return el[i].value;
			else					switch_subset(el[i].value);
		}
}

function switch_subset(newset) {
	yellowize_subset(window["spec_" + dataset]["values"][window["spec_" + dataset]["subset"]], "");
	yellowize_subset(window["spec_" + dataset]["values"][newset], highlight);
	window["spec_" + dataset]["subset"] = newset;
	if (dataset !== "isotope") {
		document.getElementById("l_" + dataset).getElementsByTagName("span")[0].innerHTML = " " + window["spec_" + dataset]["values"][newset] + " ";
		update_detail(active, dataset);
	}
	colorize_and_mass(true);
	if (tab === "PropertyTab" && dataset !== "chemical") save_colors(current_colors);
}

function switch_viz(newset) {
	if (dataset === "state" && wholetable.inverted) leave_state();
	if (dataset === "melt" || dataset === "boil") temp_to_series();
	dataset = newset;
	if (dataset === "series" || dataset === "isotope" || dataset === "orbital" || dataset === "chemical") restore_colors(current_colors = []);
	if (tab === "PropertyTab") {
		if (oldYellow) yellowize(oldYellow, "");
		yellowize(dataset, highlight);
		oldYellow = dataset;
	}
	init_slider();
	if (tab === "PropertyTab" && dataset !== "chemical") save_colors(current_colors);
}

function yellowize(el, color) {
	document.getElementById("l_" + el).parentNode.style.backgroundColor = color;
	document.getElementById("t_" + el).parentNode.style.backgroundColor = color;
	document.getElementById(el.toUpperCase()).style.backgroundColor = color;
}

function yellowize_subset(el, color) {
	document.getElementById("r_" + el).parentNode.style.backgroundColor = color;
}

function color_other(valueArray, specArray) {
	var min = 10000000000, max = 0;
	for (x in valueArray) {
		valueArray[x] *= 1;
		switch(specArray["scale"][specArray["subset"]]) {
			case "log":	valueArray[x] = Math.log(valueArray[x]); break;
			case "inv":	valueArray[x] = 1 / valueArray[x]; break;
		}
		if (valueArray[x] < min && valueArray[x] != -Infinity && !isNaN(valueArray[x])) min = valueArray[x];
		if (valueArray[x] > max && valueArray[x] != -Infinity && !isNaN(valueArray[x])) max = valueArray[x];
	}
	for (var i = 1; i <= 118; i++) {
		if (!isNaN(valueArray[i]))
			set_bgcolor(i, calc_color(valueArray[i] == -Infinity ? min : valueArray[i], specArray["startcolor"], specArray["endcolor"], min, max));
		else
			set_bgcolor(i, "#" + specArray["defaultcolor"]);
	}
}
// above and below should be one function
function color_isotope(valueArray, specArray) {
	var min = 10000000000, max = 0;
	for (var x = 1; x < valueArray.length; x++) {
		valueArray[x] *= 1;
		switch(specArray["scale"][specArray["subset"]]) {
			case "log":	valueArray[x] = Math.log(valueArray[x]); break;
			case "inv":	valueArray[x] = 1 / valueArray[x]; break;
		}
		if (valueArray[x] < min && valueArray[x] != -Infinity && !isNaN(valueArray[x])) min = valueArray[x];
		if (valueArray[x] > max && valueArray[x] != -Infinity && !isNaN(valueArray[x])) max = valueArray[x];
	}
	for (var i = 1; i < valueArray.length; i++) {
		if (!isNaN(valueArray[i]))
			document.getElementById("isotopeholder").childNodes[i - 1].style.backgroundColor = calc_color(valueArray[i] == -Infinity ? min : valueArray[i], specArray["startcolor"], specArray["endcolor"], min, max);
		else
			document.getElementById("isotopeholder").childNodes[i - 1].style.backgroundColor = "#" + specArray["defaultcolor"];
	}
}

function init_layout() {
	element_ids = [], electron_ids = [];
	var tags = document.getElementsByTagName("td"), current, atomic;
	for (var i = 0; i < tags.length; i++) {
		if (tags[i].className.indexOf("Element") !== -1) {
			atomic = tags[i].childNodes[n_atomic].innerHTML * 1;
			element_ids[atomic] = tags[i];
			current = tags[i];
			while (current.nextSibling.nodeType != 1) current = current.nextSibling;
			electron_ids[atomic] = current.nextSibling;
		}
	}
	attach("SeriesTab");
	attach("Groups");
	search_active = false;
	document.forms["visualize"].onclick = dataset_changed;
//	document.forms["isotopes"].onclick = dataset_changed;
}

function update_tempbox() {
//	if (document.getElementById("Temperature").style.display === "block")
	temperature = display.value * 1;
	tempK.innerHTML = temperature;
	tempC.innerHTML = Math.round(temperature - 273.15);
	tempF.innerHTML = Math.round(temperature * 9/5 - 459.67);
	tempState.innerHTML = temperature + " K";
}

function click_checkbox(obj) {
	obj = this || srcElement || obj;
	var sheet_ids = {"electrons": 0, "names": 1, "masses": 2};
	var reverse_ids = ["electrons", "names", "masses"];
	for (var i = sheet_ids[obj.id]; Math.abs(i - 1) < 2; i += (obj.checked - 0.5) * 2)
		document.getElementById(reverse_ids[i]).checked = obj.checked;
	for (var x = 0; x < reverse_ids.length; x++)
		document.styleSheets[x + 1].disabled = document.getElementById(reverse_ids[x]).checked;

	if (obj.id === "wide") {
		if (iMove !== -1 && iMove !== 32) return false;
		insert_rareearths(obj.checked);
		if (tab !== "SeriesTab") {
			if (obj.checked)	tab_to_span("SeriesTab");
			else				tab_to_anchor("SeriesTab");
		}
	} else if (tab !== "OrbitalTab") init_slider();
	firstDetails = true;
	if (tab === "PropertyTab") fix_properties();

	var checkbox_ids = ["masses", "names", "electrons", "wide"];
	for (x in checkbox_ids)
		document.getElementById(checkbox_ids[x]).parentNode.className = (document.getElementById(checkbox_ids[x]).checked) ? "Selected" : "";
}

function startWikiDrag(e) {
	e = e || event;
	if ((e.srcElement || e.target).nodeName.toUpperCase() === "INPUT") return;
	document.getElementById("WikiFrameBox").style.display = "none";
	set_opacity(wikibox, 0.80);
	this.startX = this.offsetLeft;
	this.startY = this.offsetTop;
	this.mouseStartX = e.clientX;
	this.mouseStartY = e.clientY;
	document.onmousemove = moveWiki;
	document.onmouseup = releaseWiki;
	return false;
}

function moveWiki(e) {
	e = e || event;
	wikibox.style.left = wikibox.startX + e.clientX - wikibox.mouseStartX + "px";
	wikibox.style.top = wikibox.startY + e.clientY - wikibox.mouseStartY + "px";
	return false;
}

function releaseWiki(e) {
	document.onmousemove = null;
	document.onmouseup = null;
	set_opacity(wikibox, 1);
	document.getElementById("WikiFrameBox").style.display = "";
}

function click_wiki(e) {
	el = this || srcElement;
	if (el.nodeName.toUpperCase() === "A") {
		var article = decodeURIComponent(el.href.substring(el.href.lastIndexOf("/") + 1));
		document.getElementById("ElementName").href = el.href;
	} else {
		var atomic = el.idx;
//		if (wikibox.style.display === "block") init_throb(atomic);
		var article = el.childNodes[n_name].innerHTML;
		document.getElementById("ElementName").href = "http://" + language + ".wikipedia.org/wiki/" + encodeURIComponent(article);
	}
	document.getElementById("ElementName").innerHTML = article;
	window.frames["WikiFrame"].location.replace("http://" + language + ".wikipedia.org/w/index.php?title=" + encodeURIComponent(article) + "&printable=yes");
	wikibox.onmousedown = startWikiDrag;
	if (atomic && wikibox.style.display !== "block") {
		document.getElementById("WikiFrameBox").style.display = document.getElementById("WikiTitle").style.display = "none";
		wikibox.style.display = "block";
		wikibox.style.backgroundColor = "";
		wikibox.style.border = "2px solid #" + schemehigh;
		wikibox.style.position = "absolute";
		wikibox.style.left = (wikibox.leftStart = -findPos(element_ids[atomic], [0, 0])[0]) + "px";
		wikibox.style.width = (wikibox.wideStart = element_ids[atomic].offsetWidth) + "px";
		wikibox.style.top = (wikibox.topStart = -findPos(element_ids[atomic], [0, 0])[1]) + "px";
		wikibox.style.height = (wikibox.highStart = element_ids[atomic].offsetHeight) + "px";
		wikibox.coverLeft = (wikibox.leftStart - 0.15 * resizewidth - (typeof document.body.style.maxHeight != "undefined" ? document.documentElement.scrollLeft : 0)) / animation_steps;
		wikibox.coverWidth = (0.7 * resizewidth - wikibox.wideStart) / animation_steps;
		wikibox.coverTop = (wikibox.topStart - 0.15 * resizeheight - (typeof document.body.style.maxHeight != "undefined" ? document.documentElement.scrollTop : 0)) / animation_steps;
		wikibox.coverHeight = (0.7 * resizeheight - wikibox.highStart) / animation_steps;
		animated_expand();
	} else {
		wikibox.style.display = "block";
		if (typeof document.body.style.maxHeight == "undefined") wikibox.style.height = 0.7 * resizeheight + "px";
		wikibox.style.backgroundColor = "white";
		wikibox.style.border = "medium outset";
	}
	return false;
}

function animated_expand() {
	wikibox.style.width = wikibox.wideStart + wikibox.coverWidth * aniX + "px";
	wikibox.style.left = wikibox.leftStart - wikibox.coverLeft * aniX + "px";
	wikibox.style.height = wikibox.highStart + wikibox.coverHeight * aniX + "px";
	wikibox.style.top = wikibox.topStart - wikibox.coverTop * aniX + "px";
	if (aniX++ < animation_steps) setTimeout(animated_expand, 10);
	else {
		aniX = 0;
		if (typeof document.body.style.maxHeight != "undefined") {
			wikibox.style.position = "fixed";
			wikibox.style.height = "";
		}
		wikibox.style.width = wikibox.style.left = wikibox.style.top = "";
		document.getElementById("WikiFrameBox").style.display = document.getElementById("WikiTitle").style.display = "";
		wikibox.style.backgroundColor = "white";
		wikibox.style.border = "medium outset";
	}
}

function destroy() {
	window.frames["WikiFrame"].location.replace("about:blank");
	wikibox.style.display = "";
}

function save_colors(colorsarray) {
	for (var i = 1; i <= 118; i++)
		colorsarray[i] = getBGcolor(element_ids[i]);
}

function getBGcolor(el) {
	if (el.currentStyle) return (el.currentStyle.backgroundColor.replace(/^#/, ""));
	else if (window.getComputedStyle) return (rgb2hex(getComputedStyle(el, null).getPropertyValue("background-color")));
}

function restore_colors(colorsarray) {
	for (var i = 1; i <= 118; i++) set_bgcolor(i, (colorsarray.length ? "#" + colorsarray[i] : ""));
}

function toggle_display(boxes, onoff) {
	for (var x in boxes)
		document.getElementById(boxes[x]).style.display = onoff;
}

function activeTab(e) {
	e = e || event;
	var name = (e.srcElement || e.target).id;
	if (!widecheck.checked || tab !== "SeriesTab") tab_to_anchor(tab);

	on_mouse_over();

	if (tab === "OrbitalTab") move_helium(false);
	switch (tab = name) {
		case "SeriesTab":
			toggle_display(["Properties", "Hund", "Block", "DecayModes", "IsotopeForm"], "none");
			toggle_display(["Series"], "");
			switch_viz("series");
			break;
		case "PropertyTab":
			toggle_display(["Hund", "Block", "DecayModes", "IsotopeForm"], "none");
			if (typeof conductivity === "undefined") load_details(datasets[tab]);
			else switch_viz(dataset_changed(true, document.forms["visualize"]));
			break;
		case "OrbitalTab":
			if (!widecheck.checked) document.getElementById("Series").style.display = "none";
			toggle_display(["Properties", "DecayModes", "IsotopeForm"], "none");
			toggle_display(["Block", "Hund"], "block");
			switch_viz("orbital");
			move_helium(true);
			break;
		case "IsotopeTab":
			if (!widecheck.checked) document.getElementById("Series").style.display = "none";
			toggle_display(["Properties", "Block", "Hund", "Closeup"], "none");
			if (document.getElementById("isotopeholder").innerHTML) {
				if (!widecheck.checked) document.getElementById("MatterState").style.display = "none";
				document.getElementById("IsotopeForm").style.display = "block";
			}
			toggle_display(["DecayModes"], "block");
			switch_viz("isotope");
			break;
	}
	attach(tab);
	on_mouse_over(active);

	tab_to_span(name);
	return false;
}

function tab_to_anchor(tab) {
	var a = document.createElement("a");
	a.id = tab;
	a.href = "#";
	a.onclick = activeTab;
	a.innerHTML = document.getElementById(tab).parentNode.replaceChild(a, document.getElementById(tab)).innerHTML;
}

function tab_to_span(name) {
	var span = document.createElement("span");
	span.id = name;
	span.innerHTML = document.getElementById(name).parentNode.replaceChild(span, document.getElementById(name)).innerHTML;
}

function findSymbol(m, sym) {
	for (var i = 1; i <= 118; i++)
		if (element_ids[i].childNodes[n_symbol].innerHTML == sym)
			return electronstring[i];
}

function tab_electron(atomic) {
	var shellcoeff = {"s": 0, "p": 0.75, "d": 1.5, "f": 2.25}, max = [0, 0], shells = [], elecstr = electronstring[atomic];
	while (elecstr.match(/\[.*\]/)) elecstr = elecstr.replace(/\[(.*)\]/, findSymbol);
	var parts = elecstr.replace(/(\d+)(\d[spdf]|$)/g, "$1 $2").split(" ");
	orbital_ids["OrbitalString"].innerHTML = elecstr.replace(spec_electronstring["replace"][0], spec_electronstring["replace"][1]);
	for (var x = 0; x < parts.length - 1; x++) {
		shells[parts[x].substr(0, 2)] = parts[x].match(/[spdf](\d+)$/)[1];
		if (Number(parts[x].charAt(0)) + shellcoeff[parts[x].charAt(1)] > max[1])
			max = [parts[x].substr(0, 2), Number(parts[x].charAt(0)) + shellcoeff[parts[x].charAt(1)], shells[parts[x].substr(0, 2)]];
	}
	for (var x = 0; x < aufbau.length; x++) {
		for (var y = 0; y < aufbau[x].length; y++) {
			var len = aufbau[x][y].parentNode.cells.length - 1;
			for (var z = 1; z <= len * 2; z++)
				aufbau[x][y].parentNode.cells[z <= len ? z : z - len].childNodes[z <= len ? 0 : 1].style.visibility = (z <= (aufbau[x][y].innerHTML.substr(0, 2) in shells ? shells[aufbau[x][y].innerHTML.substr(0, 2)] : 0) ? "visible" : "hidden");
		}
	}
	hover_orbital(max[0].charAt(1), max[2] - 1, max[0].charAt(0) - shellL[max[0].charAt(1)] - 1);
}

function hover_orbital(l, m, n) {
	if (lastOrbital) lastOrbital.className = "";
	block_ids["Orbital"].style.backgroundImage = 'url("Images/orbitals-' + l + (scheme === "night" ? "-night" : "") + '.png")';
	block_ids["Orbital"].style.backgroundPosition = "-" + (scheme === "night" ? 64 : 108) * m + "px -" + (scheme === "night" ? 64 : 108) * n + "px";
	var row = orbital_ids["Hund"].tBodies[0].rows[0].cells[shellL[l]].getElementsByTagName("table")[0].tBodies[0].rows;
	cell = row[row.length - n - 1].cells;
	lastOrbital = cell[m + 1 >= cell.length ? m - (cell.length - 2) : m + 1];
	orbital_ids["lmn"].tBodies[0].rows[0].cells[2].innerHTML = shellL[l];
	orbital_ids["lmn"].tBodies[0].rows[1].cells[2].innerHTML = (m + 1 >= cell.length ? m - (cell.length - 1) : m) - shellL[l];
	orbital_ids["lmn"].tBodies[0].rows[2].cells[2].innerHTML = n + shellL[l] + 1;
	lastOrbital.className = "HoverOrbital";
}

function attach(what) {
	switch (what) {
		case "OrbitalTab":
			var hund = orbital_ids["Hund"].tBodies[0].rows[0].cells;
			for (var i = 0; i < hund.length; i++) {
				var temp = hund[i].getElementsByTagName("table")[0].getElementsByTagName("td");
				for (var j = 0; j < temp.length; j++) {
					temp[j].l = temp[j].parentNode.cells[0].innerHTML.charAt(1);
					temp[j].n = temp[j].parentNode.cells[0].innerHTML.charAt(0) - 1 - shellL[temp[j].l];
					temp[j].m = temp[j].cellIndex - 1;
					temp[j].onmouseover = function () { hover_orbital(this.l, this.m, this.n); };
				}
			}
			for (var i = 1; i <= 118; i++) {
				element_ids[i].onmouseover = function () { on_mouse_over(this.idx); };
				element_ids[i].onclick = function () { detach(this.idx); };
			}
			break;
		case "IsotopeTab":
			for (var i = 1; i <= 118; i++) {
				element_ids[i].onmouseover = function () { on_mouse_over(this.idx); };
				element_ids[i].onclick = function () { load_isotope(this.idx); detach(this.idx); };
			}
			break;
		case "SeriesTab":
			for (var i = 1; i <= 118; i++) {
				element_ids[i].onmouseover = function () { on_mouse_over(this.idx); };
				element_ids[i].onclick = click_wiki;
			}
			break;
		case "PropertyTab":
			for (var i = 1; i <= 118; i++) {
				element_ids[i].onmouseover = function () { on_mouse_over(this.idx); };
				element_ids[i].onclick = function () { detach(this.idx); };
			}
			break;
		case "Groups":
			var groups = wholetable.tHead.rows[0].cells;
			for (var i = 1; i < groups.length; i++) {
				groups[i].firstChild.onclick = click_wiki;
				groups[i].firstChild.onmouseover = groups[i].firstChild.onmouseout = groups[i].firstChild.onfocus = groups[i].firstChild.onblur = hover_group;
			}
			for (var i = 0; i < 7; i++) {
				wholetable.tBodies[0].rows[i].cells[0].firstChild.onclick = click_wiki;
				wholetable.tBodies[0].rows[i].cells[0].onmouseover = wholetable.tBodies[0].rows[i].cells[0].onmouseout = wholetable.tBodies[0].rows[i].cells[0].firstChild.onfocus = wholetable.tBodies[0].rows[i].cells[0].firstChild.onblur = hover_period;
			}
			break;
	}
}

function detach(atomic) {
	if (lastDetach) element_ids[lastDetach].onclick = element_ids[atomic].onclick;
	on_mouse_over(atomic);
	for (var i = 1; i <= 118; i++) element_ids[i].onmouseover = null;
	element_ids[atomic].onclick = function () { on_mouse_out(); attach(tab); };
	lastDetach = atomic;
}

function showDetails(atomic, full) {
	elTarget = element_ids[atomic];
	detail.innerHTML = "";
	for (var i = 0; i < elTarget.childNodes.length; i++)
		detail.appendChild(elTarget.childNodes[i].cloneNode(true));
	detail.childNodes[n_mass].innerHTML = series[0][atomic];
	detail.childNodes[n_symbol].style.color = "";
	detailelectrons.innerHTML = electron_ids[atomic].innerHTML;
	detail.style.backgroundColor = detailelectrons.style.backgroundColor = "#" + default_colors[atomic];
	property_ids["electronstring"].innerHTML = electronstring[atomic].replace(/(\d+)(\d[spdf]|$)/g, "<sup>$1<\/sup> $2");

	if (!widecheck.checked) document.getElementById("MatterState").style.display = "none";
	document.getElementById("Closeup").style.display = "block";
	if (full) {
		if (!widecheck.checked) {
			document.getElementById("Series").style.display = "none";
			document.getElementById("Temperature").style.display = "";
		}
		document.getElementById("Properties").style.display = "block";

		property_ids["chemical"].innerHTML = get_series(atomic);
		property_ids["state"].innerHTML = element_ids[atomic].state;
		for (attribute in datasets["PropertyTab"]) update_detail(atomic, datasets["PropertyTab"][attribute]);
		if (firstDetails) fix_properties();
	}
}

function get_series(atomic) {
	return element_ids[atomic].className.substring(8, element_ids[atomic].className.lastIndexOf(" "));
}

function get_orbital(atomic) {
	return element_ids[atomic].className.slice(-1);
}

function update_detail(atomic, prop) {
	var attr = window[prop];
	var spec = window["spec_" + prop];
	var subset = spec["subset"];
	property_ids[prop].innerHTML = (typeof attr[subset][atomic] !== "undefined") ? String(attr[subset][atomic]).replace(spec["replace"][0], spec["replace"][1]) + spec["unit"][subset] : "Unknown";
}

function fix_properties() {
	var temp = document.getElementById("Properties").getElementsByTagName("table");
	temp[0].style.position = "absolute";
	temp[0].style.left = temp[1].offsetWidth + 5 + "px";
	firstDetails = false;
}

function state_classes() {
	var value = display.value * 1, tempcolor;
	for (var i = 1; i <= 118; i++) {
		tempcolor = 0;
		if (!boil[0][i] && !melt[0][i]) {
			if (element_ids[i].state !== "Unknown") {
				tempcolor = "#667766";
				element_ids[i].state = "Unknown";
			}
		} else if (value > boil[0][i]) {
			if (element_ids[i].state !== "Gas") {
				tempcolor = "#AA0000";
				element_ids[i].state = "Gas";
			}
		} else if (value > melt[0][i]) {
			if (element_ids[i].state !== "Liquid") {
				tempcolor = "#0000DD";
				element_ids[i].state = "Liquid";
			}
		} else if (element_ids[i].state !== "Solid") {
			tempcolor = "#000000";
			element_ids[i].state = "Solid";
		}
		if (tempcolor) {
			if (wholetable.inverted)	set_bgcolor(i, tempcolor);
			else						element_ids[i].childNodes[n_symbol].style.color = tempcolor;
		}
	}
}

function rgb2hex(value) {
	var hex = "", h = /(\d+)[, ]+(\d+)[, ]+(\d+)/.exec(value);
	for (var i = 1; i <= 3; i++)
		hex += (h[i] < 16 ? "0" : "") + parseInt(String(h[i])).toString(16);
	return (hex);
}

function calc_color(value, start, end, min, max) {
	var n = (value - min) / (max - min);
	end = parseInt(end, 16);
	start = parseInt(start, 16);

	var result = start +
		((( Math.round(((((end & 0xFF0000) >> 16) - ((start & 0xFF0000) >> 16)) * n))) << 16)
		+ (( Math.round(((((end & 0x00FF00) >> 8) - ((start & 0x00FF00) >> 8)) * n))) << 8)
		+ (( Math.round((((end & 0x0000FF) - (start & 0x0000FF)) * n)))));

	return "#" + ((result >= 0x100000) ? "" : (result >= 0x010000) ? "0" : (result >= 0x001000) ? "00" : (result >= 0x000100) ? "000" : (result >= 0x000010) ? "0000" : "00000") + result.toString(16);
}

function rainbow(value, start, end, min, max) {
	var x = (value - min) / (max - min);
	x = x * (end - start) + start;
	var r = 				122.713 - 954.984*x + 5593.32*Math.pow(x,2) - 16122.6*Math.pow(x,3) + 27653.9*Math.pow(x,4) - 23948.6*Math.pow(x,5) + 7875.35*Math.pow(x,6);
	var g = x >= 0.063 ?	31.9113 - 352.441*x + 7044.09*Math.pow(x,2) - 25069.8*Math.pow(x,3) + 41208.0*Math.pow(x,4) - 33020.6*Math.pow(x,5) + 10192.9*Math.pow(x,6) : 27.7353 + 35.9604*x;
	var b =					134.474 + 549.479*x + 671.189*Math.pow(x,2) - 12805.8*Math.pow(x,3) + 28800.6*Math.pow(x,4) - 25151.2*Math.pow(x,5) + 7835.32*Math.pow(x,6);
	var result = Math.round(r<<16) + Math.round(g<<8) + Math.round(b);
	return "#" + ((result >= 0x100000) ? "" : (result >= 0x010000) ? "0" : (result >= 0x001000) ? "00" : (result >= 0x000100) ? "000" : (result >= 0x000010) ? "0000" : "00000") + result.toString(16);
}

function color_temp(temparray, specArray, save) {
	var value = display.value * 1;
	var startcolor = specArray["startcolor"];
	var endcolor = specArray["endcolor"];
	var max = temparray[0];
	for (var i = 1; i <= 118; i++) {
		if (temparray[i] < value)		set_bgcolor(i, calc_color(temparray[i], startcolor, schemebase, 0, value));
		else if (temparray[i] >= value) set_bgcolor(i, calc_color(temparray[i], schemebase, endcolor, value, max));
		else							set_bgcolor(i, "#" + specArray["defaultcolor"]);
	}
	if (save) save_colors(current_colors);
}

function time_machine(discarray) {
//	elTarget.className = elTarget.className.replace(/Solid|Liquid|Gas|Unknown/, stateclass);
	var value = display.value * 1;
	for (var i = 1; i <= 118; i++) {
		if (discarray[i] < value || !discarray[i]) set_bgcolor(i, "");
		else set_bgcolor(i, "#" + schemebase);
	}
}

function search(searchstring) {
	var winners = {};
	on_mouse_out();
	for (var atomic = 1; atomic <= 118; atomic++) {
		if (!searchstring) continue;
		else if (searchstring == atomic || element_ids[atomic].childNodes[n_symbol].innerHTML.toLowerCase() == searchstring.toLowerCase()) {
			winners = {};
			winners[atomic] = true;
			break;
		} else if (element_ids[atomic].childNodes[n_name].innerHTML.toLowerCase().indexOf(searchstring.toLowerCase()) != -1)
			winners[atomic] = true;
	}
	for (var atomic = 1; atomic <= 118; atomic++) search_highlight(atomic, winners[atomic]);
	save_colors(current_colors);
	for (var atomic in winners) winlist.push(atomic);
	if (winlist.length === 1) on_mouse_over(winlist[0]);
	winlist = [];
}

function search_highlight(atomic, darken) {
	if (darken)	set_bgcolor(atomic, calc_color(3, search_colors[atomic], schemehigh, 0, 10));
	else		set_bgcolor(atomic, calc_color(6, search_colors[atomic], schemebase, 0, 10));
}

function series_to_temp() {
	if (document.getElementById("Series").style.display !== "none") {
		document.getElementById("Series").style.display = "none";
		document.getElementById("Temperature").style.display = "block";
	}
}

function temp_to_series() {
	if (document.getElementById("Temperature").style.display === "block") {
		document.getElementById("Temperature").style.display = "";
		document.getElementById("Series").style.display = "";
	}
}

function dim_for_states() {
	on_mouse_over();
	if (!widecheck.checked) document.getElementById("Closeup").style.display = "none";
	document.getElementById("MatterState").style.display = "";
	series_to_temp();
	wholetable.className += " InvertState";
	wholetable.inverted = true;
	for (var i = 1; i <= 118; i++) {
		set_bgcolor(i, element_ids[i].childNodes[n_symbol].style.color);
		element_ids[i].childNodes[n_symbol].style.color = "white";
	}
//	restore_colors(current_colors = []);
}

function leave_state() {
	wholetable.className = wholetable.className.replace(" InvertState", "");
	wholetable.inverted = false;
	for (var i = 1; i <= 118; i++) element_ids[i].childNodes[n_symbol].style.color = element_ids[i].style.backgroundColor;
	restore_colors(current_colors = []);
	temp_to_series();
}

function init_flash(tablist) {
	if (flash_num) clearInterval(flash_num);
	flash_ids = tablist;
	flash_value = 5;
	flash_num = setInterval(flash_tabs, 100);
}

function init_sliderflash() {
	if (flash_num) {
		clearInterval(flash_num);
		flash_num = false;
	} else {
		flash_value = 5;
		flash_num = setInterval(flash_slider, 100);
	}
}

function flash_tabs() {
	for (x in flash_ids)
		flash_ids[x].style.backgroundColor = (flash_value === 0 ? "" : calc_color(flash_value, "FFFF00", flash_ids[x].getElementsByTagName("input")[0].checked ? schemebase : getBGcolor(document.getElementById("Tabs")), 5, 0));
	if (flash_value-- === 0) {
		clearInterval(flash_num);
		flash_num = false;
	}
}

function flash_slider() {
	document.getElementById("SliderTrack").parentNode.style.backgroundColor = calc_color(flash_value, "FFFF00", schemebase, 5, 0);
	display.parentNode.style.backgroundColor = calc_color(flash_value, "FFFF00", schemebase, 5, 0);
	if (flash_value-- === 0) init_sliderflash();
}

function init_slider() {
	var spec = window["spec_" + dataset];
	if (("values" in spec && spec["values"].length > 6) || "slidermax" in spec) {
		if (document.getElementById("OrbitalString")) hide_slider(false);
		slider.parentNode.style.display = display.style.display = "";
		init_sliderflash();
		display.readOnly = "values" in spec;
		slider.xMax = document.getElementById("SliderSlit").offsetWidth;
		slider.from = "values" in spec ? 0 : spec["slidermin"];
		slider.to = "values" in spec ? spec["values"].length - 1 : spec["slidermax"];
		slider.scale = slider.xMax / (slider.to - slider.from);
		if (dataset === "state" && !wholetable.inverted) {
			document.getElementById("Legend").childNodes[n_mass].innerHTML = spec["Legend"][0];
			dim_for_states();
		}
		if (dataset === "melt" || dataset === "boil") series_to_temp();
		snap_slider(("values" in spec ? spec["subset"] : (spec["unit"][0] === " K") ? temperature : spec["default"] - slider.from) * slider.scale, true);
	} else {
		slider.parentNode.style.display = display.style.display = "none";
		if ("values" in spec && spec["values"].length <= 6) {
			create_radios(spec);
			switch_subset(spec["subset"]);
		} else {
			snap_slider(0, true);
			if (document.getElementById("AltSlider")) document.getElementById("AltSlider").parentNode.removeChild(document.getElementById("AltSlider"));
		}
	}
}

function create_radios(spec) {
	if (!document.getElementById("OrbitalString")) hide_slider(true);
	else if (document.getElementById("AltSlider")) document.getElementById("AltSlider").parentNode.removeChild(document.getElementById("AltSlider"));
	var form = document.createElement("form");
	form.id = "AltSlider";
	for (var x = 0; x < spec["values"].length; x++) {
		var temp = document.createElement("span");
		temp.className = "Radio";
		temp.innerHTML += ' <input type="radio" name="SliderAlt" id="r_' + spec["values"][x] + '" value="' + x + '"/>';
		var label = document.createElement("label");
		label.htmlFor = "r_" + spec["values"][x];
		label.innerHTML = spec["values"][x];
		temp.appendChild(label);
		form.appendChild(temp);
	}
	form.onclick = subset_changed;
	document.getElementById("OrbitalString").appendChild(form);
	document.getElementById("r_" + spec["values"][spec["subset"]]).checked = true;
}

function startSlide(e) {
	e = e || event;
	on_mouse_over();
	if (search_active || hovered_state !== false) return;
	if (dataset === "series" || dataset === "chemical") dim_for_states();
	if (dataset === "state") {
		if (!widecheck.checked) document.getElementById("Closeup").style.display = "none";
		document.getElementById("MatterState").style.display = "";
	}
	slider.startOffsetX = parseInt(slider.style.left) - e.screenX;
	document.onmousemove = moveSlider;
	document.onmouseup = slider_release;
	slider.onmousedown = null;
	e.cancelBubble = true;
	if (e.stopPropagation) e.stopPropagation();
	return false;
}

function slider_skip(e) {
	e = e || event;
	on_mouse_over();
	if (search_active || hovered_state !== false) return;
	var offset = (e.offsetX - slider.offsetLeft || findPos(slider, [e.pageX, 0])[0]) < 0 ? -1 : 1;
	bump_slider(offset, (slider.xMax / 10) * offset);
	return false;
}

function moveSlider(e) {
	snap_slider(Math.max(0, Math.min(slider.startOffsetX + (e || event).screenX, slider.xMax)), false);
	return false;
}

function slider_keypress(e) {
	var code = (e) ? e.which : event.keyCode;
	if (code > 31 && (code < 48 || code > 57)) return false;
}

function slider_release(e) {
	e = e || event;
	if (!keyscroll) {
		if (e.keyCode == 39 || e.keyCode == 37) return false;
		if (e.keyCode) on_mouse_over();
	}
	keyscroll = false;
	var spec = window["spec_" + dataset];
	if (dataset !== "state" && tab !== "IsotopeTab" && wholetable.inverted) leave_state();
	if ("default" in spec) spec["default"] = display.value;
	if (!("values" in spec)) snap_slider(Math.min(slider.xMax, Math.max(0, (display.value * 1 - slider.from) * slider.scale)), false);
	if (dataset !== "series" && dataset !== "chemical" && tab !== "IsotopeTab") save_colors(current_colors);
	if (e !== true) on_mouse_over(active);
	document.onmousemove = null;
	document.onmouseup = null;
	slider.onmousedown = startSlide;
}

function snap_slider(x, force) {
	var spec = window["spec_" + dataset];
	var pos = Math.round(x / slider.scale + slider.from);
	slider.style.left = (pos - slider.from) * slider.scale + "px";
	if ("values" in spec) {
		if (spec["subset"] != pos || force) {
			spec["subset"] = pos;
			display.value = spec["values"][pos];
			if (dataset !== "isotope") document.getElementById("l_" + dataset).getElementsByTagName("span")[0].innerHTML = " " + display.value + " ";
			colorize_and_mass(true);
		}
	} else {
		display.value = pos;
		if (spec["unit"][0] === " K") {
			state_classes();
			clearTimeout(slider.timer);
			slider.timer = setTimeout(update_tempbox, 15);
		}
		if (force || (dataset !== "series" && dataset !== "chemical")) colorize_and_mass((force && dataset !== "isotope") || dataset === "state");
	}
}

function write_stateword() {
	for (var i = 1; i <= 118; i++)
		element_ids[i].childNodes[n_mass].innerHTML = element_ids[i].state.replace("Unknown", " ");
}

function colorize_and_mass(includemass) {
	var attr = window[dataset];
	var spec = window["spec_" + dataset];
	if (includemass) {
		if (dataset === "state") {
			clearTimeout(slider.stateTimer);
			slider.stateTimer = setTimeout(write_stateword, 30);
		} else {
			for (var i = 1; i <= 118; i++)
				if (typeof attr[spec["subset"]][i] != "undefined") element_ids[i].childNodes[n_mass].innerHTML = String(attr[spec["subset"]][i]).replace(/([\d\.]{6})(\d+)/, "$1<span>$2</span>");
				else element_ids[i].childNodes[n_mass].innerHTML = " ";
			document.getElementById("Legend").childNodes[n_mass].innerHTML = spec["Legend"][spec["subset"]];
		}
	}

	if (tab === "IsotopeTab" && dataset !== "isotope") color_isotope(attr.concat(), spec);
	else if (dataset === "boil" || dataset === "melt") {
		clearTimeout(slider.colorTimer);
		slider.colorTimer = setTimeout(getRef2(attr[0], spec, includemass), 3);
	}
	else if (dataset === "discover") time_machine(attr[0]);
	else if (dataset !== "series" && dataset !== "state" && dataset !== "isotope" && dataset !== "chemical" && dataset !== "orbital") color_other(attr[spec["subset"]].concat(), spec);
}

function getRef2(attr, spec, includemass) {
	return function () { color_temp(attr, spec, includemass); };
}

function wheelscroll(e) {
	e = e || event;
	var skip = (e.detail) ? e.detail / Math.abs(e.detail) : e.wheelDelta / Math.abs(e.wheelDelta);
	if (skip) bump_slider(skip, skip * 3);
	slider_release(true);
	if (e.preventDefault) e.preventDefault();
	return false;
}

function on_mouse_over(atomic) {
	if (active) dark(active);
	if (atomic) {
		dim(atomic);
		if (document.getElementById("IsotopeForm").style.display !== "block") showDetails(atomic, (typeof conductivity !== "undefined" && tab === "PropertyTab"));
		if (tab === "OrbitalTab") tab_electron(atomic);
		active = atomic;
	}
}

function hide_closeup(full) {
	if (tab === "SeriesTab" && !full) on_mouse_over();
	if (tab === "SeriesTab" && !widecheck.checked) {
		document.getElementById("Closeup").style.display = "none";
		document.getElementById("MatterState").style.display = "";
	}
	if (tab === "IsotopeTab" && full === true) {
		document.getElementById("isotopeholder").innerHTML = "";
		document.getElementById("IsotopeForm").style.display = "none";
	}
}

function on_mouse_out(dontforget) {
	on_mouse_over();
	if (dontforget !== true) active = false;
	hide_closeup(true);
}

function dim(atomic, nogroup) {
	if (winlist.length !== 1) set_bgcolor(atomic, calc_color(1, (current_colors.length ? current_colors : default_colors)[atomic], schemebase, 0, 2));
	if (nogroup !== true) {
		group_period(element_ids[atomic], highlight);
		var series = get_series(atomic), orbital = get_orbital(atomic);
		if (series && series !== " " && series !== "Undiscovered") document.getElementById(series).className = "";
		if (orbital && orbital !== " ") document.getElementById(orbital).className = "";
	}
}

function dark(atomic, nogroup) {
	set_bgcolor(atomic, !current_colors.length ? "" : "#" + current_colors[atomic]);
	if (nogroup !== true) {
		group_period(element_ids[atomic], "");
		var series = get_series(atomic), orbital = get_orbital(atomic);
		if (series && series !== " " && series !== "Undiscovered") document.getElementById(series).className = series;
		if (orbital && orbital !== " ") document.getElementById(orbital).className = orbital;
	}
}

function set_opacity(el, value) {
//	el.style.opacity = value;
	el.style.filter = (value != 1) ? "alpha(Opacity=" + value * 100 + ")" : "";
}

function set_bgcolor(atomic, color) {
	element_ids[atomic].style.backgroundColor = electron_ids[atomic].style.backgroundColor = color;
}

function set_stateclass(elTarget, stateclass) {
	if (elTarget.className.indexOf(stateclass) === -1) elTarget.className = elTarget.className.replace(/Solid|Liquid|Gas|Unknown/, stateclass);
}

function move_helium(convert) {
	if (convert) {
		with (wholetable.tBodies[0].rows[0]) {
			insertBefore(element_ids[2].nextSibling, cells[3]);
			insertBefore(element_ids[2], cells[3]);
			var inserted = document.getElementById("Properties").parentNode.parentNode.parentNode.parentNode.parentNode.cellIndex + 1;
			insertCell(inserted).colSpan = 12;
			cells[inserted].id = "OrbitalString";
			orbital_ids["OrbitalString"] = cells[inserted];
			cells[5].style.display = cells[cells.length - 2].style.display = cells[cells.length - 3].style.display = "none";
		}
		wholetable.className += " s p d f";
		save_colors(default_colors);
	} else {
		with (wholetable.tBodies[0].rows[0]) {
			cells[5].style.display = cells[cells.length - 2].style.display = cells[cells.length - 3].style.display = "";
			deleteCell(orbital_ids["OrbitalString"].cellIndex);
			insertBefore(cells[3], cells[cells.length - 1]);
			insertBefore(cells[3], cells[cells.length - 1]);
		}
		wholetable.className = wholetable.className.replace(" s p d f", "");
		save_colors(default_colors);
	}
}

function hide_slider(convert) {
	if (convert) {
		with (wholetable.tBodies[0].rows[0]) {
			var inserted = document.getElementById("Properties").parentNode.parentNode.parentNode.parentNode.parentNode.cellIndex + 1;
			insertCell(inserted).colSpan = 10;
			cells[inserted].id = "OrbitalString";
			cells[cells.length - 5].style.display = cells[cells.length - 4].style.display = "none";
		}
	} else {
		with (wholetable.tBodies[0].rows[0]) {
			cells[cells.length - 5].style.display = cells[cells.length - 4].style.display = "";
			deleteCell(document.getElementById("OrbitalString").cellIndex);
		}
	}
}

function move_rare_inside() {
	var table = wholetable.tBodies[0].rows;
	table[5].insertBefore(table[9].cells[iMove + 2], table[5].cells[6]);
	table[6].insertBefore(table[10].cells[iMove], table[6].cells[6]);
	table[5].insertBefore(table[9].cells[iMove + 1], table[5].cells[6]);
	table[6].insertBefore(table[10].cells[iMove - 1], table[6].cells[6]);
	if (iMove !== 1)	table[8].cells[1].colSpan = iMove - 1;
	else				table[8].cells[1].style.display = "none";
	table[3].cells[5].colSpan = table[4].cells[5].colSpan = wholetable.tHead.rows[0].cells[3].colSpan = 31 - iMove;
	if (iMove > 20)	key_id.parentNode.colSpan = 49 - iMove;
	else			key_next.colSpan = 23 - iMove;
	iMove -= 2;
	if (iMove >= 0) setTimeout(move_rare_inside, 100);
	else {
		table[3].deleteCell(5); key_id.parentNode.rowSpan = 4;

		var moved = key_next.appendChild(document.getElementById("KeyContainer").cloneNode(true));
		moved.id = "NewContainer";
		var newcont = moved.tBodies[0].rows[0].cells;
		newcont[0].innerHTML = "";
		newcont[1].innerHTML = "";

		move_keyblocks_to(newcont);

		if (dataset === "state" || dataset === "melt" || dataset === "boil")
				document.getElementById("Temperature").style.display = "block";
		else	document.getElementById("Series").style.display = "";
		document.getElementById("MatterState").style.display = "";
		key_id.className = "Upscale";

		table[4].cells[5].innerHTML = table[7].cells[2].innerHTML;
		table[4].cells[5].style.textAlign = "center";
		table[4].cells[5].className = "Clean Paren";

		table[5].cells[5].style.display = table[6].cells[5].style.display = "none";
		key_next.colSpan = 20;
		table[4].cells[5].colSpan = wholetable.tHead.rows[0].cells[3].colSpan = 28;
		for (var i = 10; i >= 7; i--) table[i].style.display = "none";
		setTimeout(resize_hunt, 1000);
	}
}

function move_rare_outside() {
	var table = wholetable.tBodies[0].rows;
	table[9].insertBefore(table[5].cells[6], table[9].cells[iMove]);
	table[10].appendChild(table[6].cells[6]);
	table[9].insertBefore(table[5].cells[6], table[9].cells[iMove + 1]);
	table[10].appendChild(table[6].cells[6]);
	table[8].cells[1].colSpan = iMove;
	if (iMove === 30) {
		wholetable.tHead.rows[0].deleteCell(3);
		table[3].deleteCell(5);
		table[4].deleteCell(5);
		table[0].deleteCell(key_next.cellIndex);
	} else {
		wholetable.tHead.rows[0].cells[3].colSpan = table[4].cells[5].colSpan = 30 - iMove;
		if (iMove < 12) key_id.parentNode.colSpan = 30 - iMove;
		if (iMove === 12) {
			key_id.parentNode.rowSpan = 3;
			table[3].insertCell(5).colSpan = key_id.parentNode.colSpan;
		}
		if (iMove >= 12) {
			key_next.colSpan = 30 - iMove;
			table[3].cells[5].colSpan = 30 - iMove;
		}
	}
	iMove += 2;
	if (iMove <= 30) setTimeout(move_rare_outside, 100);
	else {
		table[8].cells[1].getElementsByTagName("span")[0].style.display = "";
		setTimeout(resize_hunt, 1000);
	}
}

function insert_rareearths(turnon) {
	var table = wholetable.tBodies[0].rows;

	if (turnon) {
		wholetable.tHead.rows[0].insertCell(3);

		table[3].insertCell(5); //eventually deleted
		table[4].insertCell(5);
		table[0].insertCell(document.getElementById("Series").parentNode.parentNode.parentNode.parentNode.parentNode.cellIndex + 1);
		key_next = key_id.parentNode.nextSibling;
		while (key_next.nodeType != 1) key_next = key_next.nextSibling;
		key_next.rowSpan = 3;
		key_next.colSpan = 2;
		key_next.className = "KeyRegion";

		table[8].cells[1].getElementsByTagName("span")[0].style.display = "none";

		iMove = 29;
		move_rare_inside();
	} else {
		var oldcont = document.getElementById("KeyContainer").tBodies[0].rows[0].cells;
		move_keyblocks_to(oldcont);
		key_next.innerHTML = "";

		if (document.getElementById("Properties").style.display == "block" || document.getElementById("Hund").style.display == "block" || document.getElementById("DecayModes").style.display == "block")
			document.getElementById("Series").style.display = "none";
		document.getElementById("Temperature").style.display = "";

		if (document.getElementById("Closeup").style.display === "block" || document.getElementById("IsotopeForm").style.display === "block") document.getElementById("MatterState").style.display = "none";
		key_id.className = "";

		table[5].cells[5].style.display = table[6].cells[5].style.display = table[8].cells[1].style.display = "";
		for (var i = 10; i >= 7; i--) table[i].style.display = "";
		table[4].cells[5].innerHTML = "";

		iMove = 2;
		move_rare_outside();
	}
}

function move_keyblocks_to(container) {
	container[0].appendChild(document.getElementById("Closeup"));
	container[0].appendChild(document.getElementById("IsotopeForm"));
	container[1].appendChild(document.getElementById("Properties"));
	if (tab === "PropertyTab") document.getElementById("t_" + dataset).checked = true;
	container[1].appendChild(document.getElementById("Hund"));
	container[1].appendChild(document.getElementById("Block"));
	container[1].appendChild(document.getElementById("DecayModes"));
}

function slider_arrow(e) {
	e = e || event;
	if (e.keyCode == 38 || e.keyCode == 40) {
		if (!keyscroll) on_mouse_over();
		bump_slider(39 - e.keyCode, 39 - e.keyCode);
		keyscroll++;
	}
	if (e.keyCode >= 37 && e.keyCode <= 40) {
		e.cancelBubble = true;
		if (e.stopPropagation) e.stopPropagation();
	}
}

function bump_slider(valuedist, pixeldist) {
	if ("values" in window["spec_" + dataset])
		snap_slider(Math.min(slider.xMax, Math.max(0, slider.offsetLeft + slider.scale * valuedist)), false);
	else {
		if (isNaN(display.value)) display.value = 0;
		snap_slider(Math.min(slider.xMax, Math.max(0, (display.value * 1 - slider.from) * slider.scale + 1 * pixeldist)), false);
		if (keyscroll === 2 && (dataset === "series" || dataset === "chemical")) dim_for_states();
	}
}

function slider_update(e) {
	var source = (e) ? e.which : event.keyCode;
	if (source > 31 && (source < 48 || source > 57)) return false;
}

function keyboard_nav(e) {
	e = e || event;

	switch (e.keyCode) {
		case 13:
			if ((e.srcElement || e.target).nodeName.toUpperCase() === "A") return;
			if (active) { element_ids[active].onclick(); return false; }
			return;
		case 27:
			if (wikibox.style.display == "block") { destroy(); return false; }
			return;
	}
	if (e.keyCode >= 37 && e.keyCode <= 40) {
		on_mouse_over(active || 1);
		switch (e.keyCode) {
			case 37: case 39:
				var newElement = Math.max(1, Math.min(118, active - 38 + e.keyCode));
				break;
			case 38: case 40:
				var count = 0;
				var pos = active;
				var rowind = element_ids[active].parentNode.rowIndex;
				if (e.keyCode == 40) {
					if (widecheck.checked) { if (rowind == 7) return; }
					else {
						if (rowind == 11 || pos == 39 || pos == 87 || pos == 88) return;
						if ((pos > 39 && pos < 57) || (pos > 71 && pos < 89)) pos += 15;
						else if (rowind == 10) pos += 17;
						else if (pos >= 104) pos -= 47;
					}
				} else {
					if (pos <= 2 || (pos >= 4 && pos <= 9) || (pos >= 21 && pos <= 30)) return;
					if (widecheck.checked) { if (pos >= 57 && pos <= 70) return; }
					else {
						if ((pos > 71 && pos <= 86) || rowind == 7) pos -= 15;
						else if (rowind == 11) pos -= 17;
						else if (pos > 57 && pos <= 71) pos += 62;
						else if (pos == 57) pos += 47;
					}
				}
				var row = wholetable.tBodies[0].rows[rowind - (20 - e.keyCode / 2 + (element_ids[active].cellIndex < 4 ? 1 : 0))];
				for (var i = 0; i < row.cells.length; i++) if (row.cells[i].className.indexOf("Element") != -1) count += e.keyCode - 39;
				var newElement = pos + count;
				break;
		}
		on_mouse_over(newElement);
	}
}

function group_period(el, color) {
	var period = el.parentNode.rowIndex - 1;
	wholetable.tBodies[0].rows[period > 7 ? period - 4 : period].cells[0].style.backgroundColor = color;
	if (period > 7) return;

	if (el.cellIndex < 4)
		var count = (el.cellIndex + 1) / 2;
	else {
		var count = 20 - Math.ceil((wholetable.tBodies[0].rows[period].cells.length - el.cellIndex) / 2);
		if (widecheck.checked && ++count < 4) return;
	}
	wholetable.tHead.rows[0].cells[count].style.backgroundColor = color;
}

function hover_group(e) {
	on_mouse_out(true);
	e = e || event;
	var count = this.parentNode.cellIndex, min = 0, max = 7, atomic;
	if (count > 1 && count < 18 + widecheck.checked) min++;
	if (count > 2 && count < 13 + widecheck.checked) min += 2;
	if (!widecheck.checked && count == 3) max -= 2;

	for (var x = min; x < max; x++) {
		count = this.parentNode.cellIndex;
		if (count <= 2)
			var index = count * 2 - 1;
		else {
			var index = wholetable.tBodies[0].rows[x].cells.length - (20 - count) * 2 + 1;
			if (widecheck.checked && (index -= 2) < 4) break;
		}
		atomic = wholetable.tBodies[0].rows[x].cells[index].idx;
		if (e.type == "mouseover" || e.type == "focus") dim(atomic, true);
		else if (e.type == "mouseout" || e.type == "blur") dark(atomic, true);
	}
}

function hover_period(e) {
	on_mouse_out(true);
	e = e || event;
	var period = (this.nodeName.toUpperCase() === "A" ? this.parentNode.parentNode.rowIndex : this.parentNode.rowIndex);
	var start = wholetable.rows[period].cells[1].idx;
	var end = (tab === "OrbitalTab" && start === 1 ? 2 : wholetable.rows[period].cells[wholetable.rows[period].cells.length - 3].idx);
	for (var x = start; x <= end; x++) {
		if (e.type == "mouseover" || e.type == "focus") dim(x, true);
		else if (e.type == "mouseout" || e.type == "blur") dark(x, true);
	}
}

function getAjaxObj() {
	var xmlhttp, complete = false;
	try { xmlhttp = new ActiveXObject("Microsoft.XMLHTTP"); }
	catch (e) { try { xmlhttp = new XMLHttpRequest(); }
	catch (e) { xmlhttp = false; }}
	if (!xmlhttp) return null;
	this.connect = function (sURL, sVars, fnDone) {
		if (!xmlhttp) return false;
		complete = false;
		try {
			xmlhttp.open("GET", sURL + sVars, true);
			xmlhttp.onreadystatechange = function () {
				if (xmlhttp.readyState == 4 && !complete) {
					complete = true;
					fnDone(xmlhttp, sVars);
				}
			};
			xmlhttp.send("");
		}
		catch(z) { return false; }
		return true;
	};
	return this;
}

function load_details(arrays) {
	if (!waiting) {
		waiting = true;
		throb_value = 1;
		throbber = setInterval(throb_properties, 50);
		var conn = new getAjaxObj(), list = [];
		for (set in arrays) {
			if (window[arrays[set]]) continue;
			if ("values" in window["spec_" + arrays[set]])
					list.push(arrays[set] + "-" + window["spec_" + arrays[set]]["values"].join(":").toLowerCase().replace(/\./g, ""));
			else	list.push(arrays[set]);
		}
		conn.connect("data.php?set=", list.join(","), parse_into_arrays);
	}
}

function parse_into_arrays(oXML, sVars) {
	var returned_data = oXML.responseText.split("\n");
	for (sets in returned_data) {
		temp = [];
		arrays = returned_data[sets].split("=")[1].split(":");
		for (element in arrays) temp.push(eval("[" + arrays[element] + "]"));
		window[returned_data[sets].split("=")[0]] = temp;
	}
	waiting = false;
	clearInterval(throbber);
	document.getElementById("PropertyTab").style.backgroundColor = "";
	switch_viz(dataset_changed(true, document.forms["visualize"]));
	if (tab === "PropertyTab") on_mouse_over(active || 1);
}

function init_throb(atomic) {
	if (typeof throbber !== "undefined") finish_throb(atomic, throbber);
	throb_atomic = atomic;
	throb_value = 2;
	throbber = setInterval(throb_element, 83);
}

function finish_throb(atomic, id) {
	clearInterval(id);
	set_bgcolor(atomic, "");
}

function load_isotope(atomic) {
	init_throb(atomic);
	var conn = new getAjaxObj();
	conn.connect("isotope.php?all=" + Boolean(Number(spec_isotope["subset"])) + "&set=", atomic, click_isotope);
}

function throb_element() {
	var x = throb_value++ % 8;
	set_bgcolor(throb_atomic, calc_color(x <= 4 ? x : 8 - x, default_colors[throb_atomic], schemebase, 0, 4));
}

function throb_properties() {
	var x = throb_value++ % 8;
	document.getElementById("PropertyTab").style.backgroundColor = calc_color(x <= 4 ? x : 8 - x, schemebase, "4386D9", 0, 4);
}

function click_isotope(oXML, atomic) {
	document.getElementById("Closeup").style.display = "none";
	document.getElementById("IsotopeForm").style.display = "block";

	var returned_data = oXML.responseText.split("\n");
	halflife = [], binding = [], masscontrib = [], isomass = [], neutrons = [], width = [];
	document.getElementById("isotopeholder").innerHTML = "";
	for (var sets in returned_data)
		setTimeout(getRef(atomic, sets, returned_data), sets * 75);
	document.getElementById("ISONAME").childNodes[0].innerHTML = element_ids[atomic].childNodes[n_name].innerHTML;
	document.getElementById("ISONAME").childNodes[1].innerHTML = "";
	finish_throb(atomic, throbber);
}

function getRef(atomic, sets, returned_data) {
	return function () { draw_isotope(atomic, +sets+1, returned_data[sets].split(",")); };
}

function draw_isotope(atomic, inc, specs) {
	for (i in datasets["IsotopeTab"]) window[datasets["IsotopeTab"][i]][inc] = specs[window["i_" + datasets["IsotopeTab"][i]]];
	nuclide = document.createElement("div");
	nuclide.style.visibility = "hidden";
	nuclide.onmouseover = function () {
		if (lastIsotope) lastIsotope.style.zIndex = lastIsotope.zind;
		this.style.zIndex = 100;
		isotopeDetails(this, inc);
		lastIsotope = this;
	};
	nuclide.className = element_ids[atomic].className + " " + (specs[i_decaymode] ? specs[i_decaymode] : "Stable");
	nuclide.style.lineHeight = "normal";
	nuclide.appendChild(element_ids[atomic].childNodes[n_symbol].cloneNode(true));
	nuclide.appendChild(element_ids[atomic].childNodes[n_name].cloneNode(true));
	nuclide.appendChild(element_ids[atomic].childNodes[n_mass].cloneNode(true));
	nuclide.childNodes[0].innerHTML = "<sup>" + specs[i_neutrons] + "<\/sup>" + element_ids[atomic].childNodes[n_symbol].innerHTML;
//	nuclide.childNodes[1].innerHTML += "-" + specs[i_neutrons];
	nuclide.childNodes[2].innerHTML = String(isomass[inc]).replace(/([\d\.]{6})(\d+)/, "$1<span>$2</span>");
	document.getElementById("isotopeholder").appendChild(nuclide);
	nuclide.style.position = "absolute";
	var position = findPos(element_ids[atomic], [-findPos(nuclide, [0, 0])[0], -findPos(nuclide, [0, 0])[1]]);
	nuclide.style.left = -position[0] + 20 * inc + "px";
	nuclide.style.top = -position[1] + 20 * inc + "px";
	nuclide.style.zIndex = nuclide.zind = inc + 1;
	nuclide.style.visibility = "";
}

function isotopeDetails(obj, inc) {
	document.getElementById("HALFLIFE").innerHTML = timeunits(halflife[inc]);
	document.getElementById("ISONAME").childNodes[1].innerHTML = "-" + neutrons[inc];
	document.getElementById("ISOMASS").innerHTML = isomass[inc];
	document.getElementById("BINDING").innerHTML = (binding[inc] === "") ? "Unknown" : binding[inc];
	document.getElementById("MASSCONTRIB").innerHTML = masscontrib[inc] + "%";
	document.getElementById("WIDTH").innerHTML = scinot(width[inc]);
}

function timeunits(seconds) {
	var period_name = ["y", "d", "h", "min", "s", "ms", "µfs", "ns", "ps"];
	var period_secs = [31556926, 86400, 3600, 60, 1, 1e-3, 1e-6, 1e-9, 1e-12];

	if (seconds === "0")
		return "Stable";
	else if (seconds === "")
		return "Unknown";
	else for (i in period_name)
		if (seconds > period_secs[i])
			return scinot((seconds / period_secs[i]).toPrecision(countsigfig(seconds))) + " " + period_name[i];
	return scinot((seconds / period_secs.pop()).toPrecision(countsigfig(seconds))) + " " + period_name.pop();
}

function countsigfig(num) {
	return num.replace(/^0.0*/, "").replace(/\.|e.+$/g, "").length;
}

function scinot(num) {
	return num.replace(/e[+]*(-)*(\d*)$/, "×10<sup>$1$2<\/sup>");
}

function findPos(obj, lefttop) {
	return (obj ? findPos(obj.offsetParent, [lefttop[0] - obj.offsetLeft, lefttop[1] - obj.offsetTop]) : lefttop);
}

function no_sideways() {
	var st = document.getElementById("Series");
	st.className += " WMfix";
	// measure instead of this
	if (language === "zh" || language === "ja" || language === "ko") return;
	st = st.tBodies[0];

	st.insertRow(0).insertCell(-1).colSpan = 3;
	st.rows[0].cells[0].rowSpan = 2;
	st.rows[0].appendChild(st.rows[1].cells[1]);

	st.insertRow(1).appendChild(st.rows[3].cells[5]);
	st.rows[1].cells[0].rowSpan = 1;
	st.rows[1].appendChild(st.rows[3].cells[5]);
	st.rows[1].cells[1].rowSpan = 1;
}

function load_script(file) {
	var demo = document.createElement("script");
	demo.src = "Script/" + file + ".js";
	demo.type = "text/javascript";
	document.getElementsByTagName("head")[0].appendChild(demo);
	return false;
}

function sweep() {
	var interval = 35, diagonals = [[1], [3], [4,11], [12,19], [20,37], [21,38,55], [22,39,56,87], [23,40,88], [24,41,72], [25,42,73,104], [26,43,74,105], [27,44,75,106,57], [28,45,76,107,58,89], [5,29,46,77,108,59,90], [6,13,30,47,78,109,60,91], [7,14,31,48,79,110,61,92], [8,15,32,49,80,111,62,93], [2,9,16,33,50,81,112,63,94], [10,17,34,51,82,113,64,95], [18,35,52,83,114,65,96], [36,53,84,115,66,97], [54,85,116,67,98], [86,117,68,99], [118,69,100], [70,101], [71,102], [103]];
	for (var rows = 0; rows < 30; rows++) {
		if (diagonals[rows])setTimeout("dim_diagonal([" + diagonals[rows] + "], 1);", interval * rows);
		if (diagonals[rows - 1]) setTimeout("dim_diagonal([" + diagonals[rows - 1] + "], 2);", interval * rows);
		if (diagonals[rows - 2]) setTimeout("dim_diagonal([" + diagonals[rows - 2] + "], 1);", interval * rows);
		if (diagonals[rows - 3]) setTimeout("dark_diagonal([" + diagonals[rows - 3] + "]);", interval * rows);
	}
}

function dim_diagonal(elements, color) {
	for (x in elements) set_bgcolor(elements[x], calc_color(color, default_colors[elements[x]], schemebase, 0, 3));
}

function dark_diagonal(elements) {
	for (x in elements) dark(elements[x], true);
}
