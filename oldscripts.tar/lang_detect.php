<?
$link = mysqli_connect("localhost", "ptable", "lucent", "ptable") or die(mysqli_connect_error());
require("lang_functions.php");
$debug_log = "/var/log/periodic_lang";
$debug = (array_key_exists("REMOTE_HOST", $_SERVER) ? $_SERVER["REMOTE_HOST"] : $_SERVER["REMOTE_ADDR"]) . ": ";

if (array_key_exists("lang", $_GET)) {
	if (determine_lang($_GET["lang"])) {
		$visitor_accepted[] = array("Actual" => determine_lang($_GET["lang"]), "Named" => $_GET["lang"]);
		$debug .= "ManualRequest: " . $_GET["lang"] . ". ";
	} else {
		header("HTTP/1.1 400 Bad Request");
		?><a href="http://www.ptable.com/">Periodic Table</a><?
		exit;
	}
} elseif (array_key_exists("HTTP_ACCEPT_LANGUAGE", $_SERVER)) {
	$accepted_list = explode(",", strtolower($_SERVER["HTTP_ACCEPT_LANGUAGE"]));

	foreach ($accepted_list as $locale) {
		$locale = explode(";", $locale);
		if (determine_lang(trim($locale[0]))) $visitor_accepted[] = array("Actual" => determine_lang(trim($locale[0])), "Named" => $locale[0]);
	}

	$debug .= "Detected: " . $_SERVER["HTTP_ACCEPT_LANGUAGE"] . ". ";
} else $debug .= "No LangHeader. ";

if (!(isset($visitor_accepted))) {
	$visitor_accepted[] = array("Actual" => "en", "Named" => "en");
	$debug .= "DEFAULTING. ";
}

$debug .= "Sending: " . $visitor_accepted[0]["Actual"] . ". CallingIt: " . $visitor_accepted[0]["Named"] . "\n";

header("Content-Language: " . $visitor_accepted[0]["Named"]);

$result = mysqli_query($link, "SELECT * FROM basic");
while ($row = mysqli_fetch_assoc($result)) {
	$element[$row["atomic"]] = $row;
	$en[$row["atomic"]] = $row["en"];
}
mysqli_free_result($result);

if ($visitor_accepted[0]["Actual"] == "en") {
	$visitor_lang = &$en;
	$result = mysqli_query($link, "SELECT name AS 'key',en AS 'value' FROM strings");
} else
	$result = mysqli_query($link, "SELECT basic.atomic AS 'key',IFNULL(names.`" . $visitor_accepted[0]["Actual"] . "`,basic.en) AS 'value' FROM basic,names WHERE basic.atomic = names.atomic UNION SELECT strings.name AS 'key',IFNULL(strings.`" . $visitor_accepted[0]["Actual"] . "`,strings.en) AS 'value' FROM strings");

while ($row = mysqli_fetch_assoc($result))
	$visitor_lang[$row["key"]] = $row["value"];
mysqli_free_result($result);

$code = substr($visitor_accepted[0]["Actual"], 0, 2);
$handle = fopen($debug_log, "a"); fwrite($handle, $debug); fclose($handle);
?>
