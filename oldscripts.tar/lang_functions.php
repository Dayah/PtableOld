<?
$result = mysqli_query($link, "SELECT * FROM strings WHERE name='LocalName'");
foreach (mysqli_fetch_assoc($result) as $lang=>$local)
	if ($lang != "name") $offered_langs[$lang] = $local;
mysqli_free_result($result);

function determine_lang($locale) {
	global $offered_langs;
	$british_english = array("au", "bz", "ca", "ie", "jm", "nz", "za", "tt", "gb", "zw");
	$trad_chinese = array("hk", "mo", "tw");

	$locale_array = explode("-", $locale);

	switch($locale_array[0]) {
		case "en":
			if (array_key_exists(1, $locale_array) && in_array($locale_array[1], $british_english)) return "en_gb";
			break;
		case "zh":
			if (array_key_exists(1, $locale_array) && in_array($locale_array[1], $trad_chinese)) return "zh-tw";
			break;
		case "nb":
		case "nn":
			return "no";
			break;
	}

	if (array_key_exists($locale_array[0], $offered_langs))
		return $locale_array[0];
}

function local($string) {
	global $visitor_lang;
	return $visitor_lang[$string];
}

function element($el) {
	global $code, $en, $visitor_lang, $visitor_accepted;
//	$dividerQ = array_search($el["atomic"], array(5, 13, 14, 32, 33, 51, 52, 84));
//	if (is_int($dividerQ) && $dividerQ % 2 == 0) echo " DividerB";
//	if (is_int($dividerQ)) echo " Divider", ($dividerQ % 2 ? "R" : "B");

	echo "  <td class=\"Element ", $el["series"], " ", $el["block"], "\"><strong>", $el["atomic"], "</strong> <big>", (($code == "zh" && $el["atomic"] < 112) ? $visitor_lang[$el["atomic"]] : $el["symbol"]), "</big> <em";
	if ($code == "zh") $symbols = &$en; else $symbols = &$visitor_lang;
	$width = imagettfbbox(12, 0, "Other/ARIALUNI.TTF", $symbols[$el["atomic"]]);
	if ($width[2] > 89) echo " class=\"Long\"";
	echo ">", $symbols[$el["atomic"]], "</em><div>", preg_replace("/([\d\.]{6})(\d+)/", "$1<span>$2</span>", $el["mass"]), "</div></td><td class=\"Electron ", $el["series"], " ", $el["block"], "\"><span>", str_replace(",", "<br/>", $el["electron"]), "</span></td>\n";
}

function choose_lang($displayed_in) {
	global $offered_langs;

	foreach ($offered_langs as $code => $name)
		echo "<option value=\"", $code, "\"", (($displayed_in == $code) ? " selected=\"selected\"" : ""), ">", $name, "</option>";
}

function output_links($displayed_in) {
	global $link, $en;

	if ($displayed_in == "en") {
		$result = mysqli_query($link, "SELECT * FROM strings WHERE name='Periodic Table'");
		foreach (mysqli_fetch_assoc($result) as $code=>$local)
			if ($code != "name") echo "<a href=\"/periodic/", ($code == "en" ? "" : "?lang=" . $code), "\">$local</a> | ";
		mysqli_free_result($result);
	} else echo "<a href=\"/periodic/\">Periodic Table</a>";
}

function right_to_left($lang) {
	$rtl = array("ar", "fa", "he");
	if (in_array($lang, $rtl)) return true;
	else return false;
}

function scheme() {
	if (apache_note("GEOIP_COUNTRY_CODE") == "") return "day";
	$sunrise = date_sunrise(time(), SUNFUNCS_RET_DOUBLE, apache_note("GEOIP_LATITUDE"), apache_note("GEOIP_LONGITUDE"), 96, 0);
	$sunset = date_sunset(time(), SUNFUNCS_RET_DOUBLE, apache_note("GEOIP_LATITUDE"), apache_note("GEOIP_LONGITUDE"), 96, 0);
	$now = date("H") + date("i") / 60 + date("s") / 3600;
	if ($sunrise < $sunset)
		if (($now > $sunrise) && ($now < $sunset)) return "day";
		else return "night";
	else
		if (($now > $sunrise) || ($now < $sunset)) return "day";
		else return "night";
}
?>
